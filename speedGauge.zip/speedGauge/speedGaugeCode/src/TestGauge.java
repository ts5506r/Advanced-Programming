
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import eu.hansolo.steelseries.gauges.Radial;

public class TestGauge {

    private static void createAndShowUI() {
        
        JFrame dashboard = new JFrame();
        dashboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dashboard.setLocationByPlatform(true);

        JPanel panel = new JPanel() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(500, 500);
            }
        };

        panel.setLayout(new BorderLayout());

        Radial speedGauge = new Radial();
        speedGauge.setTitle("Speed");
        speedGauge.setUnitString("mph");
        panel.add(speedGauge, BorderLayout.CENTER);
        dashboard.add(panel);

        JPanel buttonsPanel = new JPanel();
        JLabel valueLabel = new JLabel("Value:");

        final JTextField valueField = new JTextField(7);
        valueField.setText("");

        JButton button = new JButton("Set");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double value = Double.valueOf(valueField.getText());
                    speedGauge.setValueAnimated(value);
                } catch (NumberFormatException ex) {
                    //TODO - handle invalid input 
                    System.err.println("invalid input");
                }
            }
        });

        buttonsPanel.add(valueLabel);
        buttonsPanel.add(valueField);
        buttonsPanel.add(button);

        dashboard.add(buttonsPanel, BorderLayout.NORTH);

        dashboard.pack();
        dashboard.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowUI();
            }
        });
    }
}
